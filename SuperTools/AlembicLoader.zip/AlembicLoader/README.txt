############
Instructions
############

To use this tool, put it inside your SuperTools directory for Katana.

If this SuperTools directory does not exist yet:
1. create a SuperTools directory and move "AlembicLoader" inside it
2. add the SuperTools directory to your KATANA_RESOURCES path in your Katana launcher script

Once Katana is opened, you can access the tool through the node called "AlembicLoader".
Then, add the directory containing the alembics to the "folderPath" parameter and click
on the arrow to load the geometry. Once loaded, the supertool UI will be updated with the
parameters to control which assets are enabled and the versions that are used for each.

