from .Node import AlembicLoaderNode

def GetEditor():
    from .Editor import AlembicLoaderEditor
    return AlembicLoaderEditor
